You are updating an existing Design System inside Figma.

IMPORTANT:
Only apply the modifications listed below.
Do NOT modify:
- layout
- spacing
- typography scale
- existing component architecture
- naming conventions
- grid
- documentation structure
- pages not explicitly mentioned
- visual identity
- existing auto-layout behavior

Keep the current Design System exactly as it is except for the requested fixes.

-----------------------------------
STEP 1 — FIX CONTRAST ISSUES
-----------------------------------

Problem:
Some white elements placed on white backgrounds are invisible.

Apply the following fixes ONLY where visibility issues exist:

- Ensure all white surfaces have visible borders
- Add semantic border tokens to distinguish layers
- Apply contrast-compliant strokes
- Maintain minimalist SaaS visual style

Use these semantic tokens:

- color.border.default
- color.border.subtle
- color.surface.default
- color.surface.elevated

Rules:
- Cards on white backgrounds must have visible borders
- Inputs on white backgrounds must have visible strokes
- Ghost buttons on white backgrounds must remain visible
- Contrast must follow WCAG AA

Example:

Card:
- Fill → color.surface.default
- Stroke → color.border.subtle

Input:
- Fill → color.surface.default
- Stroke → color.border.default

-----------------------------------
STEP 2 — FIX BUTTON VARIANTS
-----------------------------------

Current issue:
Buttons do not behave like production-ready UI buttons.

Update ONLY the button component system.

Keep:
- current sizes
- current spacing
- current typography
- current radius
- current auto-layout

Create these Variants:

Variant:
- Filled
- Outlined
- Ghost

Sizes:
- Small
- Medium
- Large

States:
- Default
- Hover
- Focus
- Disabled

-----------------------------------
BUTTON RULES
-----------------------------------

Filled Button:
- Background uses action token
- Text is always visible
- No transparent background

Example:
Fill → color.action.primary
Text → color.text.inverse

Outlined Button:
- Transparent background
- Visible border
- Semantic border token required

Example:
Stroke → color.border.default
Text → color.text.primary

Ghost Button:
- Transparent background
- No border
- Must remain visible on white backgrounds

Example:
Text → color.action.primary
Hover → subtle surface fill

Focus State:
- Add accessible focus ring
- Use semantic focus token

Disabled State:
- Reduced opacity
- Maintain readability

-----------------------------------
STEP 3 — CREATE FOUNDATIONS PAGES
-----------------------------------

Current issue:
No dedicated Foundations pages exist.

Create ONLY these pages:

- Foundations / Colors
- Foundations / Typography
- Foundations / Spacing
- Foundations / Radius
- Foundations / Elevation

Do NOT create additional pages.

-----------------------------------
FOUNDATIONS STRUCTURE
-----------------------------------

Foundations / Colors:
Display:
- Primitive palette
- Semantic palette
- Light mode
- Dark mode

Foundations / Typography:
Display:
- Font families
- Typography scale
- Font weights
- Line heights
- Letter spacing

Foundations / Spacing:
Display:
- spacing.0
- spacing.2
- spacing.4
- spacing.8
- spacing.12
- spacing.16
- spacing.24
- spacing.32
- spacing.40
- spacing.48
- spacing.64

Foundations / Radius:
Display:
- radius.none
- radius.sm
- radius.md
- radius.lg
- radius.xl
- radius.full

Foundations / Elevation:
Display:
- shadow.sm
- shadow.md
- shadow.lg
- shadow.xl

-----------------------------------
STEP 4 — FIX TOKENS ARCHITECTURE
-----------------------------------

Current issue:
The token architecture does not strictly follow the requested hierarchy.

Rebuild ONLY the token organization.

Do NOT modify:
- component layouts
- UI structure
- visual direction

-----------------------------------
TOKEN STRUCTURE
-----------------------------------

Create EXACTLY these categories:

Primitive Tokens
- Colors
- Spacing
- Radius
- Typography

Semantic Tokens
- Background
- Surface
- Text
- Border
- Action
- Feedback

-----------------------------------
PRIMITIVE TOKENS EXAMPLES
-----------------------------------

Primitive Colors:
primitive.color.blue.50
primitive.color.blue.100
primitive.color.blue.200
primitive.color.blue.300
primitive.color.blue.400
primitive.color.blue.500
primitive.color.blue.600
primitive.color.blue.700
primitive.color.blue.800
primitive.color.blue.900

Primitive Spacing:
primitive.spacing.0
primitive.spacing.2
primitive.spacing.4
primitive.spacing.8
primitive.spacing.12
primitive.spacing.16
primitive.spacing.24
primitive.spacing.32

Primitive Radius:
primitive.radius.none
primitive.radius.sm
primitive.radius.md
primitive.radius.lg
primitive.radius.xl
primitive.radius.full

Primitive Typography:
primitive.font.family.base
primitive.font.size.md
primitive.font.weight.semibold
primitive.line.height.md

-----------------------------------
SEMANTIC TOKENS EXAMPLES
-----------------------------------

Background:
semantic.background.default
semantic.background.inverse

Surface:
semantic.surface.default
semantic.surface.elevated

Text:
semantic.text.primary
semantic.text.secondary
semantic.text.inverse

Border:
semantic.border.default
semantic.border.subtle
semantic.border.focus

Action:
semantic.action.primary
semantic.action.secondary

Feedback:
semantic.feedback.success
semantic.feedback.warning
semantic.feedback.error

-----------------------------------
STEP 5 — APPLY TOKENS TO COMPONENTS
-----------------------------------

Apply semantic tokens to existing components.

Examples:

Button Filled:
Background → semantic.action.primary
Text → semantic.text.inverse

Outlined Button:
Stroke → semantic.border.default
Text → semantic.text.primary

Card:
Fill → semantic.surface.default
Stroke → semantic.border.subtle

Input:
Fill → semantic.surface.default
Stroke → semantic.border.default
Placeholder → semantic.text.secondary

-----------------------------------
STEP 6 — VARIABLES & MODES
-----------------------------------

Create Figma Variables for:
- Primitive Tokens
- Semantic Tokens

Create Modes:
- Light
- Dark

Rules:
- Semantic tokens must reference primitive tokens
- Components must use semantic tokens only
- Do not apply primitive tokens directly to components

Example:

semantic.action.primary
→ references
primitive.color.blue.600

semantic.text.primary
→ references
primitive.color.neutral.900

-----------------------------------
FINAL RULES
-----------------------------------

Do NOT redesign the Design System.
Do NOT generate new visual styles.
Do NOT modify existing layouts.

Only:
- fix visibility
- improve button variants
- create Foundations pages
- correct token hierarchy
- apply semantic token logic
- preserve the current system structure